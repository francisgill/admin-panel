<?php $__env->startSection('content'); ?>



<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('ok')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('ok')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Edit User:</h4>
						</div>
						<div class="form-body">
							<form method="post" action="<?php echo e(url('update-user')); ?>"> 
								 <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="row"> 
								<div class="col-sm-12">
								  <input type="hidden" name="id" class="form-control" value="<?php echo e($user->id); ?>" />
								  <input name="name" class="form-control" value="<?php echo e($user->name); ?>" />
							 	</div>
								 </div>
							 	<div class="row">
								 <div class="col-sm-12"> 
								  <input name="email" class="form-control" value="<?php echo e($user->email); ?>" />
							 	</div>
								 </div>
							 	<div class="row">
								 <div class="col-sm-12"> 
								  <input type="hidden" name="old_password" value="<?php echo e($user->password); ?>" />
								  <input name="new_password" class="form-control" value="" placeholder="leave empty if no change" />
							 	</div>
								 </div>

							  	<div class="row"> 
							
	                            <?php echo e(csrf_field()); ?>

								<div class="col-sm-8">
								<?php 
								$sub_data = \DB::table('users')
								->join('roles','roles.id','=','users.role_id')
	        					->select('roles.id','roles.role')
	        					->get();	 
	        					?>
       
								<?php $__currentLoopData = $sub_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($sub_data->id ==  $user->role_id): ?>
								<input class="form-control" disabled value="<?php echo e($sub_data->role); ?>"/>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
							 <div class="col-sm-4">
							 <select name="role_id" class="form-control">
                            <?php $__currentLoopData = \DB::table('roles')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        	 </div>
						    </div> 
							<div class="row">
							<div class="col-sm-12">
							<button type="submit" class="btn btn-default">Submit</button> 
                            </div>
							</div>
                            </form> 
						</div>
					</div>
					</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>