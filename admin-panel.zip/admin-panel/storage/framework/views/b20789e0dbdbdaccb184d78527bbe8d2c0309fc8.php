<?php $__env->startSection('content'); ?>



<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('msg')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('msg')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Add Coupon:</h4>
						</div>
						<div class="form-body">
						<form method="POST" action="<?php echo e(url('add-coupon')); ?>" enctype="multipart/form-data">

							<div class="form-group"> 
                            <?php echo e(csrf_field()); ?>

							<input type="text" name="merchant_name" class="form-control" placeholder="Enter Merchant Name Here"> 
                            
							<div class="row">
                            <input type="text" name="location" class="form-control" placeholder="Enter Location Here"> 
                            </div>

							<div class="row">
                            <input type="date" name="expiry" class="form-control"> 
                            </div>

							<div class="row">
                            <input type="file" name="coupon_image" class="form-control" > 
                            </div>


							</div> 
                            <button type="submit" class="btn btn-default">Submit</button> 
                            </form> 
						</div>
					</div>
					</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>