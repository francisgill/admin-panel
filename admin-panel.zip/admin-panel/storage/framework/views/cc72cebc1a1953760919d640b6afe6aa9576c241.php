<?php $__env->startSection('content'); ?>



<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('ok')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('ok')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Add Role:</h4>
						</div>
						<div class="form-body">
							<form method="post" action="<?php echo e(url('add-role')); ?>"> <div class="form-group"> 
                            <?php echo e(csrf_field()); ?>

                            <input type="text" name="role" class="form-control" placeholder="Enter Role Name Here"> 
                            </div> 
                            <button type="submit" class="btn btn-default">Submit</button> 
                            </form> 
						</div>
					</div>
					</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>