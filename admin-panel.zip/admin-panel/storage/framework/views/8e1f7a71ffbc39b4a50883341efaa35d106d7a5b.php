<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>JS Bin</title>
</head>
<body>
  
  <canvas id="graph" width="400" height="400"></canvas>  
  <script src="<?php echo e(url('charts/Chart.min.js')); ?>"></script>
<script>
var data = {
  labels: ['January', 'February', 'March'],
  
  datasets: [
    {
      data: [30, 122, 90]
    },
    {
      data: [10, 52, 2]
    }
  ]
};

var context = document.querySelector('#graph').getContext('2d');

new Chart(context).Bar(data);
</script>
</body>
</html>