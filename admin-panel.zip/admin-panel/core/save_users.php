<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

$name  = $_POST['name'];

function rs($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$randomString = rs(60);





$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin-panel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}else {


        


$sqlin="INSERT INTO test VALUES ('$name')";
$result=$conn->query($sqlin);
if ($result === TRUE) {
echo json_encode($name);
} 
else {
 echo "Error: " . $sqlin . "<br>" . $conn->error;
 }
 }
 $conn->close();
?>