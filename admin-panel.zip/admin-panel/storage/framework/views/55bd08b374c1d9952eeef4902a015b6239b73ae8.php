<?php $__env->startSection('content'); ?>



<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('ok')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('ok')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Edit Coupon:</h4>
						</div>
						<div class="form-body">
							<form method="post" enctype="multipart/form-data" action="<?php echo e(url('update-coupon')); ?>"> <div class="form-group"> 
                            <?php echo e(csrf_field()); ?>

                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" value="<?php echo e($data->id); ?>" name="id"> 
							<div class="row">
							<div class="col-sm-12">
							<label for="">Coupon Code</label>
                            <input type="text" value="<?php echo e($data->coupon_code); ?>" disabled  class="form-control" placeholder="Enter Location Here"> 
                            </div>
							</div>
							
							<div class="row">
							<div class="col-sm-12">
                            <label for="">Merchant Name</label>
							<input type="text" value="<?php echo e($data->merchant_name); ?>" name="merchant_name" class="form-control"> 
							</div>
							</div>
														
							<div class="row">
							<div class="col-sm-12">
							<label for="">Location</label>
                            <input type="text" value="<?php echo e($data->location); ?>" name="location" class="form-control" placeholder="Enter Location Here"> 
                            </div>
							</div>

							<div class="row">
							<div class="col-sm-12">
							<label for="">Expiry</label>
                            <input type="date" value="<?php echo e($data->expiry); ?>" name="expiry" class="form-control"> 
                            </div>
							 </div>

							<div class="row">
							<img style="height:350px; width:100%;" src="<?php echo e(asset('storage/'.$data->coupon_image)); ?>" alt="" />
                   			<br>
							<input type="file"  name="coupon_image" class="form-control" > 
                            </div>

						    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div> 
                            <button type="submit" class="btn btn-default">Submit</button> 
                            </form> 
						</div>
					</div>
					</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>