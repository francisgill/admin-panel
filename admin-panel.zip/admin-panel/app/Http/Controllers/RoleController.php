<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

class RoleController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function list(){
        
        $roles = array_except(\DB::table('roles')->get(),['0']);
      
        return view('roles.roles',['roles'=>$roles]);
    }

    public function save(Request $req){

        $ok = \DB::table('roles')->insert([
            'role'=>$req->role,
            'created_at'=>now(),
            'updated_at'=>now(),

        ]);
        if($ok){
        return back()->with('ok','Role has been created.');
        }

        else{
            return back()->with('err','Role has not been created.');
         }
    
    }


    public function edit_role($id){

        return view('roles.edit_role',['roles'=>\DB::table('roles')->where('id',$id)->get()]);
    }

    public function update_role(Request $req){

        $ok = \DB::table('roles')->where('id',$req->id)->update([
            'role'=>$req->role,
            'created_at'=>now(),
            'updated_at'=>now(),
        ]);
        if($ok){
        return back()->with('ok','Role has been Update.');
        }

        else{
            return back()->with('err','Role has not been Update.');
         }
    
    }

    public function delete_role($id){



        $check = \DB::table('users')->where('role_id',$id)->update([
            'role_id'=>0,
            'created_at'=>now(),
            'updated_at'=>now(),
        ]);
      //  dd($check);
        $ok = \DB::table('roles')->where('id',$id)->delete();
        if($ok){
        return back()->with('ok','Role has been Deleted.');
        }

        else{
            return back()->with('err','Role has not been Deleted.');
         }
    
    }
}
