<?php $__env->startSection('content'); ?>

<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('msg')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('msg')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>
			<div class="main-page">
            <a href="<?php echo e(url('add-coupon')); ?>" class="btn btn-default">Add Coupon</a>
                    
                    
                    <div class="tables">
					<div class="table-responsive bs-example widget-shadow">
                    <table class="table table-bordered"> 
                    <tbody>   
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr> 
                    <th>Id</th> 
                    <td><?php echo e($data->id); ?></td>     
                    </tr> 
                    <tr> 
                    <th>Merchant Name</th> 
                    <td><?php echo e($data->merchant_name); ?></td>  
                    </tr> 
                    <tr> 
                    <th>Coupon Code</th> 
                    <td><?php echo e($data->coupon_code); ?></td>     
                    </tr> 
                    <tr> 
                    <th>Location</th> 
                    <td><?php echo e($data->location); ?></td>  
                    </tr> 

                    <tr> 
                    <th>Expiry</th> 
                    <td><?php echo e($data->expiry); ?></td>  
                    </tr> 

                  
                    </tbody> 
                    </table> 
                    <img style="height:350px; width:100%;" src="<?php echo e(asset('storage/'.$data->coupon_image)); ?>" alt="" />
                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>