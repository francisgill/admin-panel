<?php $__env->startSection('content'); ?>

<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('ok')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('ok')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>
			<div class="main-page">
            <a href="<?php echo e(url('add-user')); ?>" class="btn btn-default">Add User</a>
				<div class="tables">
					<div class="table-responsive bs-example widget-shadow">
						<table class="table"> 
                        <thead> 
                        <tr>  
                        <th>Id</th> 
                        <th>Name</th> 
                        <th>Email</th>
                        <th>Role</th>
                        <th>Action</th> 
                        </tr> 
                        </thead> 
                        <tbody> 
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td>
                        <a class="btn btn-primary" href="<?php echo e(url('edit-user')); ?>/<?php echo e($user->id); ?>">Edit</a> 
                        |
                         <a class="btn btn-danger" href="<?php echo e(url('delete-user')); ?>/<?php echo e($user->id); ?>">Delete</a></td> 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table> 
					</div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>