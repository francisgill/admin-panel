<form method="post" action="<?php echo e(url('add_users_api')); ?>"> <div class="form-group"> 
<?php echo e(csrf_field()); ?>

<div class="row">
<input type="text" name="name" class="form-control" placeholder="Enter Name Here"> 
</div>
<div class="row">
<input type="email" name="email" class="form-control" placeholder="Enter Email Here"> 
</div>
<div class="row">
<input type="password" name="password" class="form-control" placeholder="Enter Password Here"> 
</div>

<div class="row">
<select name="role_id" class="form-control">
<option value="null">Select</option>

<option value="0">Unsigned</option>
</select> 
</div> 

<div class="row">
<button type="submit" class="btn btn-default">Submit</button> 
</div>
</form> 
