@extends('layouts.admin-app')

@section('content')



<div id="page-wrapper" style="min-height: 611px;">

@if (session()->has('msg'))
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> {{session('msg')}}
</div>
@endif

@if (session()->has('err'))
<div class="alert alert-danger" role="alert">
{{session('err')}}
</div>
@endif

<div class="main-page">
<div class="forms">

<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
<div class="form-title">
<h4>Edit Vendor:</h4>
</div>
<div class="form-body">
<form method="post" action="{{url('update-user')}}"> 
@foreach($user as $user)
<div class="row"> 
<div class="col-sm-12">
<input type="hidden" name="id" class="form-control" value="{{$user->id}}" />
<input name="name" class="form-control" value="{{$user->name}}" />
</div>
</div>
<div class="row">
<div class="col-sm-12"> 
<input name="email" class="form-control" value="{{$user->email}}" />
</div>
</div>
<div class="row">
<div class="col-sm-12"> 
<input type="hidden" name="old_password" value="{{$user->password}}" />
<input name="new_password" class="form-control" value="" placeholder="leave empty if no change" />
</div>
</div>

<div class="row"> 

{{csrf_field()}}
<div class="col-sm-8">
@php 
$sub_data = \DB::table('users')
->join('roles','roles.id','=','users.role_id')
->select('roles.id','roles.role')
->where('users.id',$user->id)
->get();	
@endphp

@foreach($sub_data as $sub_data)
<input class="form-control" disabled value="{{$sub_data->role}}"/>
@endforeach
</div>
@endforeach

<div class="col-sm-4">
<select name="role_id" class="form-control">
@foreach(\DB::table('roles')->get() as $role)
<option value="{{$role->id}}">{{$role->role}}</option>

@endforeach
</select>
</div>
</div> 
<div class="row">
<div class="col-sm-12">
<button type="submit" class="btn btn-default">Submit</button> 
</div>
</div>
</form> 
</div>
</div>
</div>
</div>
</div>
@endsection
