<?php

Route::view('/add-role', 'roles.add_role');
Route::post('/add-role', 'RoleController@save');
Route::get('/edit-role/{id}', 'RoleController@edit_role');
Route::post('/update-role', 'RoleController@update_role');
Route::get('/delete-role/{id}', 'RoleController@delete_role');
Route::get('/roles', 'RoleController@list');


Route::view('/add-user', 'users.add_user');
Route::post('/add-user', 'UserController@save');
Route::get('/edit-user/{id}', 'UserController@edit');
Route::post('/update-user', 'UserController@update');
Route::get('/delete-user/{id}', 'UserController@delete');
Route::get('/users', 'UserController@list');

Auth::routes();
Route::get('/', 'HomeController@index')->middleware('auth')->name('home');
Route::get('/home', 'HomeController@index')->name('home');





