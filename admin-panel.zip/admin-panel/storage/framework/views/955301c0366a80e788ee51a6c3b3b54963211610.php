<?php $__env->startSection('content'); ?>

<div id="page-wrapper" style="min-height: 611px;">
			<div class="main-page">
                <div class="alert danger">
<?php if(session()->has('msg')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('msg')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>
                </div>

				<div class="tables">
					<div class="table-responsive bs-example widget-shadow">
						<h4>Clients:</h4>
						<table class="table"> 
                        <tbody> 
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td style="width:80%;"><?php echo e($chat->chat_user_name); ?></td>
                        <td>
                        <a class="btn btn-primary" href="<?php echo e(url('chats')); ?>/<?php echo e($chat->id); ?>">Chat</a> 
                        |
                         <a class="btn btn-danger" href="<?php echo e(url('delete-chat-user')); ?>/<?php echo e($chat->id); ?>">Delete</a></td> 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table> 
					</div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>