<?php $__env->startSection('content'); ?>



<div id="page-wrapper" style="min-height: 611px;">

<?php if(session()->has('ok')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('ok')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Add User:</h4>
						</div>
						<div class="form-body">
							<form method="post" action="<?php echo e(url('add-user')); ?>"> <div class="form-group"> 
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
							<input type="text" name="name" class="form-control" placeholder="Enter Name Here"> 
							</div>
							<div class="row">
							<input type="email" name="email" class="form-control" placeholder="Enter Email Here"> 
							</div>
							<div class="row">
							<input type="password" name="password" class="form-control" placeholder="Enter Password Here"> 
                            </div>

							<div class="row">
							<select name="role_id" class="form-control">
							<option value="null">Select</option>
							<?php $__currentLoopData = \DB::table('roles')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select> 
                            </div> 
							
							<div class="row">
                            <button type="submit" class="btn btn-default">Submit</button> 
							</div>
                            </form> 
						</div>
					</div>
					
					</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>