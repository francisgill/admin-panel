@extends('layouts.admin-app')

@section('content')



<div id="page-wrapper" style="min-height: 611px;">

@if (session()->has('ok'))
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> {{session('ok')}}
</div>
@endif

@if (session()->has('err'))
<div class="alert alert-danger" role="alert">
{{session('err')}}
</div>
@endif

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Add Role:</h4>
						</div>
						<div class="form-body">
							<form method="post" action="{{url('add-role')}}"> <div class="form-group"> 
                            {{csrf_field()}}
                            <input type="text" name="role" class="form-control" placeholder="Enter Role Name Here"> 
                            </div> 
                            <button type="submit" class="btn btn-default">Submit</button> 
                            </form> 
						</div>
					</div>
					</div>
			</div>
		</div>
@endsection
