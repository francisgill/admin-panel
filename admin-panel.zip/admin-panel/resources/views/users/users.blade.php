@extends('layouts.admin-app')

@section('content')

<div id="page-wrapper" style="min-height: 611px;">

@if (session()->has('ok'))
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> {{session('ok')}}
</div>
@endif

@if (session()->has('err'))
<div class="alert alert-danger" role="alert">
{{session('err')}}
</div>
@endif
			<div class="main-page">
            <a href="{{url('add-user')}}" class="btn btn-default">Add User</a>
				<div class="tables">
					<div class="table-responsive bs-example widget-shadow">
						<table class="table"> 
                        <thead> 
                        <tr>  
                        <th>Id</th> 
                        <th>Name</th> 
                        <th>Email</th>
                        <th>Role</th>
                        <th>Action</th> 
                        </tr> 
                        </thead> 
                        <tbody> 
                        @foreach($users as $user)
                        <tr>
                        <td>{{$user->id}}</td>
                        <td>{{$user->name}}</td>
                        <td>{{$user->email}}</td>
                        <td>{{$user->role}}</td>
                        <td>
                        <a class="btn btn-primary" href="{{url('edit-user')}}/{{$user->id}}">Edit</a> 
                        |
                         <a class="btn btn-danger" href="{{url('delete-user')}}/{{$user->id}}">Delete</a></td> 
                        </tr>
                        @endforeach
                       </tbody>
                    </table> 
					</div>
				</div>
			</div>
		</div>
@endsection
