<?php $__env->startSection('content'); ?>

<div id="page-wrapper" style="min-height: 611px;">
<?php if(session()->has('msg')): ?>
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> <?php echo e(session('msg')); ?>

</div>
<?php endif; ?>

<?php if(session()->has('err')): ?>
<div class="alert alert-danger" role="alert">
<?php echo e(session('err')); ?>

</div>
<?php endif; ?>
			<div class="main-page">
            <a href="<?php echo e(url('add-coupon')); ?>" class="btn btn-default">Add Coupon</a>
				<div class="tables">
					<div class="table-responsive bs-example widget-shadow">
						<table class="table"> 
                        <thead> 
                        <tr>  
                        <th>Id</th> 
                        <th>Merchant Name</th> 
                        <th>Coupen Code</th>
                        <th>Action</th> 
                        </tr> 
                        </thead> 
                        <tbody> 
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($data->id); ?></td>
                        <td><?php echo e($data->merchant_name); ?></td>
                        <td><?php echo e($data->coupon_code); ?></td>
                        <td>
                        <a class="btn btn-info" href="<?php echo e(url('coupon-single')); ?>/<?php echo e($data->id); ?>">View</a> 
                        | 
                        <a class="btn btn-primary" href="<?php echo e(url('edit-coupon')); ?>/<?php echo e($data->id); ?>">Edit</a> 
                        |
                        <a class="btn btn-danger" href="<?php echo e(url('delete-coupon')); ?>/<?php echo e($data->id); ?>">Delete</a>
                        </td> 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table> 
					</div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>