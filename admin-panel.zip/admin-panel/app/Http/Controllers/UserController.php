<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Contracts\Encryption\DecryptionException;
use Auth;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function list(){
      
        $users = \DB::table('users')
        ->join('roles','roles.id','=','users.role_id')
        ->select('roles.role','users.*')
        ->get();
//        dd($users);
        return view('users.users',['users'=>$users]);
    }

    public function save(Request $req){
        //dd($req->all());
            $ok = \DB::table('users')->insert([
            'name'=>$req->name,
            'email'=>$req->email,
            'password'=>bcrypt($req->password),
            'role_id'=>$req->role_id,
            'created_at'=>now(),
            'updated_at'=>now(),

        ]);
        if($ok){
        return back()->with('ok','User has been created.');
        }

        else{
            return back()->with('err','User has not been created.');
         }
    
    }


    public function edit($id){

        $data = \DB::table('users')  
        ->where('id',$id)->get();
       //dd($data);
        return view('users.edit_user',['user'=> $data,]);
    }

    public function update(Request $req){

        if($req->new_password == ''){
        $password = $req->old_password;  
       
    } 
        else{
            $password = bcrypt($req->new_password); 
     }
    

        $ok = \DB::table('users')->where('id',$req->id)->update([
            'name'=>$req->name,
            'email'=>$req->email,
            'password'=> $password,
            'role_id'=>$req->role_id
        ]);

        if($ok){
        return back()->with('ok','User has been Update.');
        }

        else{
            return back()->with('err','User has not been Update.');
         }
    
    }

    public function delete($id){
        if($id != Auth::user()->id){

            
        $ok = \DB::table('users')->where('id',$id)->delete();
        if($ok){
        return back()->with('ok','User has been Deleted.');
        }

        else{
            return back()->with("err","You can't delete yourself.");
         }


        }

        else{
            return back()->with("err","You can't delete yourself.");
         }

    
    }




	
}
