<?php

use Illuminate\Http\Request;


Route::get('/users', function(){
return response()->json(\DB::table('users')->get());
});


Route::post('/add_user',function(Request $request){

    $data = \DB::table('users')->insert([

        'name' => $request->name,
        'email' => $request->email,
        'password'=>bcrypt($request->password),
        'remember_token'=> str_random(60),
        'created_at'=>now(),
        'updated_at'=>now(),
        'role_id' => 0

    ]);
    
    return response()->json($request->all());

});
