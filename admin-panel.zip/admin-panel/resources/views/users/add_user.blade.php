@extends('layouts.admin-app')

@section('content')



<div id="page-wrapper" style="min-height: 611px;">

@if (session()->has('ok'))
<div class="alert alert-success" role="alert">
<strong>Well done!</strong> {{session('ok')}}
</div>
@endif

@if (session()->has('err'))
<div class="alert alert-danger" role="alert">
{{session('err')}}
</div>
@endif

			<div class="main-page">
            <div class="forms">
					
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Add User:</h4>
						</div>
						<div class="form-body">
							<form method="post" action="{{url('add-user')}}"> <div class="form-group"> 
                            {{csrf_field()}}
                            <div class="row">
							<input type="text" name="name" class="form-control" placeholder="Enter Name Here"> 
							</div>
							<div class="row">
							<input type="email" name="email" class="form-control" placeholder="Enter Email Here"> 
							</div>
							<div class="row">
							<input type="password" name="password" class="form-control" placeholder="Enter Password Here"> 
                            </div>

							<div class="row">
							<select name="role_id" class="form-control">
							<option value="null">Select</option>
							@foreach(\DB::table('roles')->get() as $role)
							<option value="{{$role->id}}">{{$role->role}}</option>
							@endforeach
							</select> 
                            </div> 
							
							<div class="row">
                            <button type="submit" class="btn btn-default">Submit</button> 
							</div>
                            </form> 
						</div>
					</div>
					
					</div>
			</div>
		</div>
@endsection
