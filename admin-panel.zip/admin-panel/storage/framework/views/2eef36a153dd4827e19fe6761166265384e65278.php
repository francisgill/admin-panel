<?php $__env->startSection('content'); ?>

<div id="page-wrapper" style="min-height: 611px;">
			<div class="main-page">
            <a href="<?php echo e(url('add-role')); ?>" class="btn btn-default">Add Role</a>
				<div class="tables">
					<div class="table-responsive bs-example widget-shadow">
						<table class="table"> 
                        <thead> 
                        <tr>  
                        <th>Id</th> 
                        <th>Role</th> 
                        <th>Action</th> 
                        </tr> 
                        </thead> 
                        <tbody> 
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($role->id); ?></td>
                        <td style="width:70%;"><?php echo e($role->role); ?></td>
                        <td>
                        <a class="btn btn-primary" href="<?php echo e(url('edit-role')); ?>/<?php echo e($role->id); ?>">Edit</a> 
                        |
                         <a class="btn btn-danger" href="<?php echo e(url('delete-role')); ?>/<?php echo e($role->id); ?>">Delete</a></td> 
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table> 
					</div>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>