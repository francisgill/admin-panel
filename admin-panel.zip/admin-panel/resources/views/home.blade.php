@extends('layouts.admin-app')

@section('content')
<div id="page-wrapper" style="min-height: 611px;">
<div class="main-page">

<?php 

function rs($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    echo $randomString;
}
rs(60);
?>

</div>
</div>

@endsection
