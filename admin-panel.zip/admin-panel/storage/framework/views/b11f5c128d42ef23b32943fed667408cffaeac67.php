<?php $__env->startSection('content'); ?>

<div id="page-wrapper" style="min-height: 611px;">
            <div class="main-page">

        <div class="col-md-12 profile widget-shadow chat-mdl-grid">
            
                        <h4 class="title3">client name:</h4>
                        <div class="scrollbar scrollbar1" tabindex="5000" style="overflow: hidden; outline: none;">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if($msg->admin_id == $msg->sid ): ?>
                        <div class="activity-row activity-row1 activity-right">
                                <div class="col-xs-3 activity-img"><img src="<?php echo e(url('images/3.png')); ?>" class="img-responsive" alt=""></div>
                                <div class="col-xs-9 activity-img1">
                                    <div class="activity-desc-sub">
                                        <p><?php echo e($msg->msg); ?></p>
                                        <span>6:52 PM</span>
                                    </div>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <?php endif; ?>
                                 <?php if($msg->user_id == $msg->sid ): ?>
                            <div class="activity-row activity-row1 activity-left">
                                <div class="col-xs-9 activity-img2">
                                    <div class="activity-desc-sub1">
                                        <p><?php echo e($msg->msg); ?></p>
                                        <span class="right">7:00 PM</span>
                                    </div>
                                </div>
                                <div class="col-xs-3 activity-img"><img src="<?php echo e(url('images/2.png')); ?>" class="img-responsive" alt=""></div>
                                <div class="clearfix"> </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                            
                            
                        </div>
    <div class="chat-bottom">
    <form  id="form" method="POST" action="<?php echo e(url('api/msg')); ?>">
    <?php echo e(csrf_field()); ?>

    <input class="form-control" id="msg" name="msg" value="">
    <input type="hidden" name="user_id" value="<?php echo e($msg->user_id); ?>">
    <input type="hidden" name="sid" value="0">
    <br>
    <input style="display:none;" class="form-control btn btn-primary" id="btn" type="submit">
    </form>
    </div>

                    </div>          
                        
                                            
<div class="clearfix"> </div>


            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>